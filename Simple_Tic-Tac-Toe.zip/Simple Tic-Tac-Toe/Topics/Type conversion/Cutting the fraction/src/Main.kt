fun main() {
    val a = readLine()!!.toDouble()
    println(a.toLong())
}