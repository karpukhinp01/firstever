fun main(args: Array<String>) {
    println(Int.SIZE_BITS)
    println(Int.MIN_VALUE)
    println(Int.MAX_VALUE)
}