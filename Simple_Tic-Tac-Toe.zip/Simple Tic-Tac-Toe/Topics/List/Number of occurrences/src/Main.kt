fun solution(strings: List<String>, str: String): Int {
    var sum = 0
    for (word in strings) {
        if (word == str) sum++
    }
    return sum
}
