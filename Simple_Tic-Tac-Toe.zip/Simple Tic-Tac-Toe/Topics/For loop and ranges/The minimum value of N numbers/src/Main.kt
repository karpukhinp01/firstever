fun main() {
    var a: Int = Int.MAX_VALUE
    val n = readLine()!!.toInt()
    for (i in 0 until n) {
        val b = readLine()!!.toInt()
        if (b <= a) a = b
    }
    println(a)
}
