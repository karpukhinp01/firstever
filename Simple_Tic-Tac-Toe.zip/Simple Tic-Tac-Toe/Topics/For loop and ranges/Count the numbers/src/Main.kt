fun main() {
    val (a) = Array(3) { readLine()!!.toCharArray()}
    println(a[0] == a[1] - 1 && a[1] == a[2] - 1)
}