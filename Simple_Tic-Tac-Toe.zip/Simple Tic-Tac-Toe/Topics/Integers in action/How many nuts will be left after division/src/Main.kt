fun main() {
    val n = readLine()!!.toInt()
    val k = readLine()!!.toInt()
    println(k % n)
}
