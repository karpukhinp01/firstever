fun main() {
    val a = readLine()!!.toInt()
    println(a / 100 + a / 10 + a % 10)
}