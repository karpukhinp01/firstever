fun main() {
    val magic = 2_000_000_000
    val giant = 3_000_000_000
    val x = magic + magic + 1
    println(x is Long)
}