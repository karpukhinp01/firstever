fun main() {
    val p = readLine()!!.toInt()
    println(p / 10)
}
