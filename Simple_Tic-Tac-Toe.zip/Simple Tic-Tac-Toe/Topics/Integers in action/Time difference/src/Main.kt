fun main() {
    val hour1 = readLine()!!.toInt()
    val min1 = readLine()!!.toInt()
    val sec1 = readLine()!!.toInt()

    val hour2 = readLine()!!.toInt()
    val min2 = readLine()!!.toInt()
    val sec2 = readLine()!!.toInt()
    println(sec2 + min2 * 60 + hour2 * 60 * 60 - (sec1 + min1 * 60 + hour1 * 60 * 60))
}
