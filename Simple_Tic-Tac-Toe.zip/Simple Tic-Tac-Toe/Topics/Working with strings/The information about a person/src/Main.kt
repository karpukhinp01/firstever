fun main() {
    val a = readLine()!!.split(" ")
    println("${a[0].first()}. ${a[1]}, ${a[2]} years old")
}