fun main() {
    val (a, b) = Array(2) { readLine()!! }
    println(a == b)
}
