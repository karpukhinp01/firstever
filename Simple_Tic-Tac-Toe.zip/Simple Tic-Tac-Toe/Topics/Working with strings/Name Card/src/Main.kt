fun main() {
    val a = readLine()!!.first()
    val b = readLine()!!
    println("$a. $b")
}