fun main() {
    println("2 + 2 = 4")
}