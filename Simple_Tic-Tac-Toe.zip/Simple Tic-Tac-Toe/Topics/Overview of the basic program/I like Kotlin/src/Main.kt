fun main() {
    println("I like Kotlin")
}