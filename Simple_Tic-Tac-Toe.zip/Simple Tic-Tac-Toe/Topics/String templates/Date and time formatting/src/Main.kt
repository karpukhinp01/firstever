fun main() {
    val s = readLine()!!.split(" ")
    val d = readLine()!!.split(" ")
    println("${s[0]}:${s[1]}:${s[2]} ${d[0]}/${d[1]}/${d[2]}")
}