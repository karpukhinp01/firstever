fun main() {
    val a = readLine()!!
    val b = readLine()!!
    println("$a $b")
}