fun main() {
    val n1 = readLine()!!.toInt()
    val n2 = readLine()!!.toInt()
    val sum = n1 + n2
    println("$n1 plus $n2 equals $sum")

}