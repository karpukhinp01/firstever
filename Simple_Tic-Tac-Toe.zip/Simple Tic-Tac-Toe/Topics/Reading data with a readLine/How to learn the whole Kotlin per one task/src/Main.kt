fun main() {
    val a = readLine()!!
    val b = readLine()!!
    val c = readLine()!!
    val d = readLine()!!
    val f = readLine()!!
    print("$a $b $c $d $f")
}