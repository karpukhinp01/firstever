fun main() {
    val a = readLine()!!.toDouble()
    print(a)
}
