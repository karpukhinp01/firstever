val n: Int = readLine()!!.toInt()
