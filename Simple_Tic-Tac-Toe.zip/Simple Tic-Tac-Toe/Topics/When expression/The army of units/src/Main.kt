fun main() {
    val a = readLine()!!.toInt()
    when {
        a < 1 -> println("no army")
        a in 1..4 -> println("few")
        a in 5..9 -> println("several")
        a in 10..19 -> println("pack")
        a in 20..49 -> println("lots")
        a in 50..99 -> println("horde")
        a in 100..249 -> println("throng")
        a in 250..499 -> println("swarm")
        a in 500..999 -> println("zounds")
        a >= 1000 -> println("legion")
    }
}