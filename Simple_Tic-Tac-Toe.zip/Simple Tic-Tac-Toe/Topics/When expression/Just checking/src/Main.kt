fun main() {
    val a = readLine()!!.toInt()
    when (a) {
        1 -> println("No!")
        2 -> println("Yes!")
        3 -> println("No!")
        4 -> println("No!")
        else -> println("Unknown number")
    }
}