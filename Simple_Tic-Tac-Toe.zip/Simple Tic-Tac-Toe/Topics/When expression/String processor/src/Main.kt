fun main() {
    val (s1, op, s2) = Array(3) { readLine()!! }
    when (op) {
        "equals" -> println(s1.equals(s2))
        "plus" -> println(s1 + s2)
        "endsWith" -> println(s1.endsWith(s2))
        else -> println("Unknown operation")
    }
}
