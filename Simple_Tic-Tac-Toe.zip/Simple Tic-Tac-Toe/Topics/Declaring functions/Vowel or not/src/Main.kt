fun isVowel(a: Char): Boolean {
    val b = a.lowercaseChar()
    if (b == 'a' || b == 'e' || b == 'i' || b == 'o' || b == 'u') return true
    else return false
}

fun main() {
    val letter = readLine()!!.first()

    println(isVowel(letter))
}
