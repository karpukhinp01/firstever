fun main() {
    val a = readLine()!!.first().lowercaseChar()
    val b = readLine()!!.first().lowercaseChar()
    println(a == b)
}