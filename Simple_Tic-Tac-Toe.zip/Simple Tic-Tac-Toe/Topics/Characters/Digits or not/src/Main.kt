fun main() {
    val (a) = readLine()!!.first()

}