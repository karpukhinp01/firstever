fun main() {
    val b = readLine()!!.toInt()
    val a = readLine()!!.first().code
    println(a == b)
}