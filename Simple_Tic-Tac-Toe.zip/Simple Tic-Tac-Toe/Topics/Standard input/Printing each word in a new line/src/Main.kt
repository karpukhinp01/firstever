import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    val c: MutableList<String> = emptyList<String>().toMutableList()
    for (i in 1..5) {
        val a = scanner.next()
        c.add(a)
    }
    for (i in c) {
        println(i)
    }
}
