import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    println(scanner.next())
    println(scanner.next())
    println(scanner.nextInt())
    println(scanner.nextInt())
}