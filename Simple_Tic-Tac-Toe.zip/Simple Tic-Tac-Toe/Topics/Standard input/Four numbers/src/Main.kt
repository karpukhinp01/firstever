import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    var b: MutableList<Int> = emptyList<Int>().toMutableList()
    for (i in 1..4) {
        val a = scanner.nextInt()
        b.add(a)
    }
    for (i in b) {
        println(i)
    }
}