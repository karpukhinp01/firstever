fun main() {
    val a = readLine()!!
    if (a.length > 1) println(a[a.length - 1] + a.substring(1, a.length - 1) + a[0]) else println(a)
}
