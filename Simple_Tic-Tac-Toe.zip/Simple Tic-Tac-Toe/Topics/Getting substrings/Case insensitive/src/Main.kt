fun compare(a: String, b: String) {
    if (a.lowercase() == b.lowercase()) println(true) else print(false)
}

fun main() {
    val a = readLine()!!
    val b = readLine()!!
    compare(a, b)
}