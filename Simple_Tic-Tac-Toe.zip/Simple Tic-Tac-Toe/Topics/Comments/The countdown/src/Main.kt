fun main() {

    println("three!")
    println("two!")
    println("one!")
    println("go!")
    //println("go!")
}