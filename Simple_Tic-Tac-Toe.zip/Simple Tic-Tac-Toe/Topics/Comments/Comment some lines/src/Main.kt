fun main() {
//    println(1)
//    println(2)
//    println(3)
//    println(4)
    println(5)
    println(6)
    println(7)
//    println(8)
}