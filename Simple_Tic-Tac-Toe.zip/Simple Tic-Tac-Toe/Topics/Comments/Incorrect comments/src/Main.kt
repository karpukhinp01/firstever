fun main() {

    println("Yet another simple Kotlin application")
    // println("Do not print this line")
}