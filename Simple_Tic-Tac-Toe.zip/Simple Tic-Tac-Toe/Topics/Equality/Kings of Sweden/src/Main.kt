val kingCharlesTheEleventh = Human()
val kingCarolusRex = Human()  

var king = kingCharlesTheEleventh
king = kingCarolusRex
