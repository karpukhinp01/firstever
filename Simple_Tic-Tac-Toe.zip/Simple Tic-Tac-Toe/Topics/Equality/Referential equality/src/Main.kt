var pirateJackSparrow = Sailor("None")
var captainJackSparrow = Sailor("None") 
println(pirateJackSparrow === captainJackSparrow)
