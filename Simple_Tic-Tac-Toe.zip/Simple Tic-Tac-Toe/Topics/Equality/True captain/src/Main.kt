var captain = Pirate("Hector Barbossa")
println(captain.name) // Do not touch this line
captain = Pirate("Jack Sparrow")
println(captain.name)
