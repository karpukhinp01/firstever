import java.util.Scanner



fun main() {
    val scanner  = Scanner(System.`in`)
    val a = Array(3) { scanner.nextInt() }
    val b = Array(3) { scanner.nextInt() }
    a.sort()
    b.sort()
    if (a.contentEquals(b)) println("Box 1 = Box 2")
    else if (a[0] >= b[0] && a[1] >= b[1] && a[2] >= b[2]) println("Box 1 > Box 2")
    else if (a[0] <= b[0] && a[1] <= b[1] && a[2] <= b[2]) println("Box 1 < Box 2")
    else println("Incomparable")
}