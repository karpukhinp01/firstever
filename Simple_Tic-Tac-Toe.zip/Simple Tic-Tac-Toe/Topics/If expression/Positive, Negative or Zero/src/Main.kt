fun main() {
    val a = readLine()!!.toInt()
    if (a > 0) { println("positive") } else if (a < 0) { println("negative") } else println("zero")
}
