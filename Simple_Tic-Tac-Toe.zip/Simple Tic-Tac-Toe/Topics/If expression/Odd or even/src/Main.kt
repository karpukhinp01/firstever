fun main() {
    val a = readLine()!!.toInt()
    if (a % 2 == 0) { println("EVEN") } else println("ODD")
}
