fun main() {
    val a = readLine()!!.toInt()
    println(if (a > 0) "YES" else "NO")
}