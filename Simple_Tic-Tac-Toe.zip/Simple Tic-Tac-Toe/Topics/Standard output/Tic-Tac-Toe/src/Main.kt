fun main() {
    println("O X X")
    println("O X O")
    println("X O X")
}