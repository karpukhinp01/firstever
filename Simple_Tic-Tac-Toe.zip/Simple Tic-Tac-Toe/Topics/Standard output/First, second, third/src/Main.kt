fun main() {
    println("first")
    println("second")
    println("third")
}