fun main() {
    val n = readLine()!!.toInt()
    var a = 0
    repeat(n) {
        val b = readLine()!!.toInt()
        if (b % 4 == 0 && b > a) a = b
    }
    println(a)
}
