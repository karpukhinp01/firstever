fun main() {
    val a = readLine()!!.toInt()
    var perfect = 0
    var larger = 0
    var smaller = 0
    repeat(a) {
        val e = readLine()!!.toInt()
        if (e == 0) perfect++ else if (e == 1) larger++ else smaller++
    }
    println("$perfect $larger $smaller")
}
