fun main() {
    val n = readLine()!!.toInt()
    val a = Array(n) { readLine()!!.toInt() }
    if (a.lastIndex >= 1) {
        val b = IntArray(n)
        for (i in 0..b.lastIndex - 1) {
            b[i + 1] = a[i]
        }
        b[0] = a[a.lastIndex]
        println(b.joinToString(" "))
    }
    else println(a.joinToString())
}
