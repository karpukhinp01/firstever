fun main() {
    val n = readLine()!!.toInt()
    val a = IntArray(n)
    for (i in 0..a.lastIndex) {
        a[i] = readLine()!!.toInt()
    }
    val m = readLine()!!.toInt()
    var s = 0
    for (i in a.indices) {
        if (a[i] == m) s++
    }
    println(s)
}
