fun main() {
    val n = readLine()!!.toInt()
    val a = IntArray(n)
    var s = 0
    for (i in 0..a.lastIndex) {
        a[i] = readLine()!!.toInt()
    }
    for (i in 0..a.lastIndex) {
        if (a[i] == a.maxOrNull()) { s = i
        a[i] = Int.MAX_VALUE }
    }
    println(s)
}
