fun main() {
    val n = readLine()!!.toInt()
    val a = Array(n) { readLine()!!.toInt() }
    var s = 0
    if (a.lastIndex > 1) {
        for (i in 1..a.lastIndex - 1) {
        if (a[i] == a[i + 1] - 1 && a[i - 1] + 1 == a[i]) s++
        }
    }
    println(s)
}
