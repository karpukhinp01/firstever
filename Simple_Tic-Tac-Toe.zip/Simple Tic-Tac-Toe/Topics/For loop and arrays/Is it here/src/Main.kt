
fun main() {
    val n = readLine()!!.toInt()
    val a = IntArray(n)
    for (i in 0..a.lastIndex) {
        a[i] = readLine()!!.toInt()
    }
    val m = readLine()!!.toInt()
    if (m in a) println("YES") else println("NO")
}
