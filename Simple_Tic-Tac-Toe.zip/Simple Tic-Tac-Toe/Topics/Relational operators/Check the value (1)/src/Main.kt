fun main() {
    val a = readLine()!!.toInt()
    println(a < 10 && a > 0)
}