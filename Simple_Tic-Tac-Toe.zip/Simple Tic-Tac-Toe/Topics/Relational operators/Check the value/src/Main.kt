fun main() {
    val a = readLine()!!.toInt()
    println(a < 10)
}
