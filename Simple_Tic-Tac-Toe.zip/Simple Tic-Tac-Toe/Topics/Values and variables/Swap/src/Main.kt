fun main() {
    var (a, b) = readLine()!!.split(" ").map { it.toInt() }

    val c = a
    a = b
    b = c
    // Do not touch the lines below
    print("$a $b")
}
