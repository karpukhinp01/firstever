package tictactoe

import java.lang.reflect.Array

fun isNumber(a: String): Boolean {
    if (a.isEmpty()) return false
    for (i in a) {
        if (!i.isDigit()) return false
    }
    return true
}


fun makeAmove(a: String, b:String): String {
    var wrongCoord = ""
    if (isNumber(a) && isNumber(b)) {
        if (a.toInt() in 1..3 && b.toInt() in 1..3) {
            wrongCoord = "ok"
        } else  wrongCoord = "Coordinates should be from 1 to 3!"
    } else wrongCoord = "You should enter numbers!"
    return wrongCoord
}

fun main() {

    val a = "_ _ _ _ _ _ _ _ _".split(" ")
    val b = arrayOf(
        arrayOf(a[0], a[1], a[2]),
        arrayOf(a[3], a[4], a[5]),
        arrayOf(a[6], a[7], a[8])
    ).toMutableList()
    



    fun printField() {
        println(
            """
        ---------
        | ${b[0].joinToString(" ")} |
        | ${b[1].joinToString(" ")} |
        | ${b[2].joinToString(" ")} |
        ---------
    """.trimIndent()
        )
    }
    printField()

    fun checkState(b: MutableList<kotlin.Array<String>>): String {
        var xwin = false
        var owin = false
        var impossible = false
        var gameNotFinished = false
        for (i in b){           //horizontal win
            if (i[0] == i[1] && i[1] == i[2]) {
                if (i.contains("X")) xwin = true
                if (i.contains("O")) owin = true
            }
        }

        for (i in 0..2) {       //vertical win
            if (b[0][i] == b[1][i] && b[1][i] == b[2][i]) {
                if (b[0][i] == "X") xwin = true
                if (b[0][i] == "O") owin = true
            }
        }
                                //diagonal win
        if ((b[0][0] == b[1][1] && b[1][1] == b[2][2]) || (b[0][2] == b[1][1] && b[1][1] == b[2][0])) {
            if (b[1][1] == "X") xwin = true else if (b[1][1] == "O") owin = true
        }

                                //impossible
        var countX = 0
        var countO = 0
        for (i in a) {
            if (i == "X") countX++ else if (i == "O") countO++
        }
        if ((xwin && owin) || (countO > (countX + 1) || countX > (countO + 1)))
        { impossible = true
            xwin = false
            owin = false }


                                //game not finished
        if ((b[0].contains("_") || b[1].contains("_") || b[2].contains("_"))
                    && !xwin && !owin && !impossible) gameNotFinished = true
        when {
            xwin -> return("X wins")
            owin -> return("O wins")
            impossible -> return("Impossible")
            gameNotFinished -> return("Game not finished")
            else -> return("Draw")
        }
    }

    // ENTER COORD 4/5

    var coord: List<String>
    var counteven = 1
    while (checkState(b) == "Game not finished") {
        do {
            print("Enter the coordinates: ")
            coord = readLine()!!.split(" ")
            while (true) {
                if (coord.size == 2) {
                    if (makeAmove(coord[0], coord[1]) == "ok") break else println(makeAmove(coord[0], coord[1]))
                } else println("You should enter numbers!")
                print("Enter the coordinates: ")
                coord = readLine()!!.split(" ")
            }
            if ((b[coord[0].toInt() - 1][coord[1].toInt() - 1]) == "_") break
            else println("This cell is occupied! Choose another one!")
        } while (true)
        if (counteven % 2 != 0) {
            b[coord[0].toInt() - 1][coord[1].toInt() - 1] = "X"
            counteven++
        } else {
            b[coord[0].toInt() - 1][coord[1].toInt() - 1] = "O"
            counteven ++
        }
        printField()
    }
    println(checkState(b))
    
}








