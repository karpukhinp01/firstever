fun main (){
    for (i in  1..9){
        println(i)
        i++
    }
}