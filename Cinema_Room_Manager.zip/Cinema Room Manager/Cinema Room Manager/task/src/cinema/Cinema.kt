package cinema

fun createCinema (rows: Int, seats: Int): MutableList<MutableList<String>> {
    var cinema = mutableListOf<MutableList<String>>()
    var numeration = mutableListOf<String>(" ")
    for (i in 1..seats) {
        numeration.add("$i")
    }
    cinema.add(numeration)
    for (i in 1..rows) {
        var temp = mutableListOf<String>("$i")
        for (j in 1..seats) {
            temp.add("S")
        }
        cinema.add(temp)
    }
    return cinema
}

fun printCinema (a: MutableList<MutableList<String>>) {
    println("Cinema:")
    for (i in a.indices) {
        println(a[i].joinToString(" "))
    }
    println()
}

fun ticketPrice (rows: Int, seats: Int, desRow: Int): Int {
    var ticketp = 0
    if (rows * seats <= 60) ticketp = 10 else if (rows % 2 == 0) {
        if (desRow < rows / 2) ticketp = 10 else ticketp = 8
        } else if (desRow <= rows / 2) ticketp = 10 else ticketp = 8
    return ticketp
}

fun statistics (cinema: MutableList<MutableList<String>>, currentIncome: Int, rows: Int, seats: Int): String {
    var purTickets = 0
    var sumSeats = rows * seats
    for (i in cinema.indices) {
        for (j in cinema[i].indices) {
            if (cinema[i][j] == "B") {
                purTickets++
            }
        }
    }
    val perc: String = if (purTickets != 0) {"%.2f".format( purTickets.toDouble() / sumSeats.toDouble() * 100) }
    else "0.00"

    val totalIncome = if (seats * rows <= 60) { seats * rows * 10 }
    else if (rows % 2 == 0) {(seats * (rows / 2) * 10) + (seats * (rows / 2) * 8)}
    else {(seats * (rows / 2) * 10) + (seats * ((rows / 2) + 1) * 8)}

    return "Number of purchased tickets: $purTickets\n" +
            "Percentage: $perc%\n" +
            "Current income: $$currentIncome\n" +
            "Total income: $$totalIncome\n"

}


    fun main() {
        var desRow: Int
        var desSeat: Int
        print(
            """Enter the number of rows:
    |> 
    """.trimMargin()
        )
        val rows = readLine()!!.toInt()
        print(
            """Enter the number of seats in each row:
    |> 
    """.trimMargin()
        )
        val seats = readLine()!!.toInt()
        println()
        var cinema = createCinema(rows, seats)
        var currentIncome = 0

        while (true) {
            print(
                """1. Show the seats
            |2. Buy a ticket
            |3. Statistics
            |0. Exit
            |> 
        """.trimMargin()
            )
            var menu = readLine()!!.toInt()
            println()
            when (menu) {
                1 -> printCinema(cinema)
                2 -> {  while (true) {
                    print(
                        """Enter a row number:
            |> 
        """.trimMargin()
                    )


                    while (true) {
                        try {
                            desRow =
                                readLine()!!.toInt()
                            break
                        } catch (e: Exception) {
                            println("Wrong input!")
                            print(
                                """Enter a row number:
            |> 
        """.trimMargin()
                            )
                        }

                    }
                    print(
                        """Enter a seat number in that row:
            |> 
        """.trimMargin()
                    )


                    while (true) {
                        try {
                            desSeat =
                                readLine()!!.toInt()
                            break
                        } catch (e: Exception) {
                            println("Wrong input!")
                            print(
                                """Enter a seat number in that row:
            |> 
        """.trimMargin()
                            )
                        }
                    }

                    if (desRow !in cinema.indices || desSeat !in cinema[1].indices) {
                        println("Wrong input!")
                        continue
                    }

                    if (cinema[desRow][desSeat] == "B") {
                        println("That ticket has already been purchased!")
                        continue
                    }
                    break
                }

                    println("Ticket price: $${ticketPrice(rows, seats, desRow)}")
                    currentIncome += ticketPrice(rows, seats, desRow)
                    cinema[desRow][desSeat] = "B"
                    println()
                }
                3 -> println(statistics(cinema, currentIncome, rows, seats))
                0 -> break
            }
        }
    }
/*
        if (seats * rows <= 60) { println("""Total Income:
        |$${seats * rows * 10}
    """.trimMargin()) } else if (rows % 2 == 0) {
            println("""Total Income:
        |$${(seats * (rows / 2) * 10) + (seats * (rows / 2) * 8)}
    """.trimMargin())
        } else println("""Total Income:
        |$${(seats * (rows / 2) * 10) + (seats * ((rows / 2) + 1) * 8)}
    """.trimMargin())
    }
*/