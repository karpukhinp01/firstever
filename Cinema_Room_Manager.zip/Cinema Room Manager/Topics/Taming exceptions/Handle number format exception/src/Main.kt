fun parseCardNumber(cardNumber: String): Long {
    val a = cardNumber.split(" ")
    if (a.size != 4) throw Exception("Incorrect format!")
    for (i in a.indices) {
        for (j in a[i].indices) {
            if (!a[i][j].isDigit()) throw Exception("Incorrect format!")
        }
    }
    return a.joinToString("").toLong()
}
