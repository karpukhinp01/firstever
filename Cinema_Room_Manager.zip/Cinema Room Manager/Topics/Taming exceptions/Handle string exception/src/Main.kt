fun main() {
    val index = readLine()!!.toInt()
    val word = readLine()!!
    println(word[index])
}